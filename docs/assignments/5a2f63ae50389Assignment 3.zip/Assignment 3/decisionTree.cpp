#include <stdio.h>
#include <math.h>
#include <sstream>
#include <map>
#include <stdlib.h>
#include <vector>
#include <fstream>
#include <algorithm>
#include <ctime>
#define THRESHOLDVALUE 10

#include <iostream>
using namespace std;

struct node
{
    int attribute;
    double gain;
    int className;
    double threshold;
    bool isLeaf;
    node* leftChild;
    node* rightChild;
};
string option;




void readFile(vector<vector <double> >& table, string fileName){
    vector<string> fileInString;
    ifstream code(fileName.c_str());
    string s;
    if(code.is_open())
        while(getline(code, s))
            fileInString.push_back(s);
    code.close();
    double x = 0;
    for(int i=0; i < fileInString.size(); i++){
        vector<double> v;
        stringstream ss(fileInString[i]);
        while(ss >> x)
            v.push_back(x);
        table.push_back(v);
    }
    fileInString.clear();

}






void minimumMaximum(vector<vector <double> > &table, int index, double &min, double &max){
    min = 999999; max = -999999;
    for(int i=0;i <table.size();i++){
        if(table[i][index] > max) max = table[i][index];
        if(table[i][index] < min) min = table[i][index];
    }
}




double informationGain(vector<vector <double> >&examples, int attribute, double threshold){
    double gain=0,instances = (double)examples.size(),cols = (double)examples[0].size(),left=0,right=0;
    vector<int> classes;
    for(int i = 0; i < instances; i++){
        if (find(classes.begin(), classes.end(), examples[i][cols - 1]) != classes.end()) continue;
        classes.push_back(examples[i][cols - 1]);
    }
    for(int i=0;i<instances;i++){
        if(examples[i][attribute]<threshold) left++;
        else right++;
    }

    int classSize = classes.size();
    int allClasses[classSize], leftClasses[classSize], rightClasses[classSize];

    for (int i=0;i<classSize;i++){
        allClasses[i] = 0;leftClasses[i] = 0;rightClasses[i] = 0;
    }

    for (int i = 0; i < instances; i++){
        int index;
        for (int j = 0; j < classSize; j++){
            if(classes[j] == examples[i][cols-1]) index = examples[i][cols-1];
        }
        allClasses[index] = allClasses[index] + 1;

        if(examples[i][attribute] < threshold) leftClasses[index] = leftClasses[index] + 1;
        else rightClasses[index] = rightClasses[index] + 1;
    }

    for(int i=0;i<classSize;i++){
        int val = allClasses[i];
        if(val>0) gain = gain + (-((val/instances)*log2(val/instances)));
    }

    if (left>0){
        for(int i=0;i<classSize;i++){
            int val = leftClasses[i];
            if (val > 0) gain = gain - (left/instances) * (-((val/left)*log2(val/left)));
        }
    }

    if (right>0){
        for(int i=0;i<classSize;i++){
            int val = rightClasses[i];
            if (val > 0) gain = gain - (right/instances) * (-((val/right)*log2(val/right)));
        }
    }

    return gain;
}




double optimizedAttribute(vector<vector <double> > &table, int& bstAttr, double &bstThresh){
    double maxGain = -1;
    bstAttr = -1;
    bstThresh = -1;
    for(int attribute = 0; attribute < table[0].size() - 1; attribute++)
    {
        double min,max;
        minimumMaximum(table, attribute, min, max);
        for (int K = 1; K <= 50; K++){
            double threshold = min + K*(max-min)/51;
            double gain = informationGain(table, attribute, threshold);
            if (gain > maxGain){
                maxGain = gain;
                bstAttr = attribute;
                bstThresh = threshold;
            }
        }
    }
    return maxGain;
}





double randomizedAttribute(vector<vector <double> > &table, int& bstAttr, double &bstThresh, int forest){
    double maxGain = -1;
    bstAttr = -1;
    bstThresh = -1;
    for(int i = 0; i < forest; i++){
        srand(time(0));
        int randAttribute = (int) rand() % (table[0].size());
        double min, max;
        minimumMaximum(table, randAttribute, min, max);
        for (int K = 1; K <= 50; K++){
            double threshold = min + K*(max-min)/51;
            double gain = informationGain(table, randAttribute, threshold);
            if (gain > maxGain){
                maxGain = gain;
                bstAttr = randAttribute;
                bstThresh = threshold;
            }
        }
    }
    return maxGain;
}




bool hasSameClass(vector<vector <double> > &table){
    int lastCol = table[0].size() - 1;
    double firstVal = table[1][lastCol];
    for ( int i = 0; i < table.size(); i++)
        if (firstVal != table[i][lastCol])
            return false;
    return true;
}




int findDefaultClass(const vector<vector <double> > &table){
    int index = table[0].size()-1;
    int row = table.size() ;
    int currentMax = 0;
    int defaultClass = table[0][index];
    map<double , int> classCounter;

    for(int i = 0 ; i < row ; i++){
        int count = classCounter[table[i][index]];
        classCounter[table[i][index]] = count + 1;
        if(count + 1 > currentMax){
            currentMax = count + 1;
            defaultClass = table[i][index];
        }
    }
    return defaultClass;
}





int testData(vector <double> &line, node* myNode, int defaultClass){
    int val;
    while (!myNode->isLeaf){
        double value = line[myNode->attribute];
        if(value < myNode->threshold) myNode = myNode->leftChild;
        else myNode = myNode->rightChild;
        if (myNode == NULL){
            val = defaultClass;
            break;
        }

    }
    val = myNode->className;

    return val;
}



node* makeTree(vector<vector <double> > &table, int defaultClass){
    node* myNode = new node;
    vector<vector <double> > leftExamples;
    vector<vector <double> > rightExamples;

    if (table.size() < THRESHOLDVALUE){
        myNode->isLeaf = true;
        myNode->className = defaultClass;
        myNode->gain = 0;
        return myNode;
    }
    if (hasSameClass(table)){
        myNode->isLeaf = true;
        myNode->className = table[0][table[0].size()-1];
        myNode->gain = 0;
        return myNode;
    }
    else{
        int bstAttr;
        double bstThresh;
        if(option == "optimized")
            myNode->gain = optimizedAttribute(table, bstAttr, bstThresh);
        else if(option == "randomized")
            myNode->gain = randomizedAttribute(table, bstAttr, bstThresh, 1);
        else if(option == "forest3")
            myNode->gain = randomizedAttribute(table, bstAttr, bstThresh, 3);
        else if(option == "forest15")
            myNode->gain = randomizedAttribute(table, bstAttr, bstThresh, 15);

        myNode->attribute = bstAttr;
        myNode->threshold = bstThresh;

        for(int i = 0; i < table.size() ; i++)
        {
            if(table[i][bstAttr] < bstThresh)
                leftExamples.push_back(table[i]);
            else
                rightExamples.push_back(table[i]);
        }
        printf("feature=%2d, thr=%6.2lf, gain=%lf\n",bstAttr, bstThresh, myNode->gain);
        myNode->leftChild = makeTree(leftExamples, findDefaultClass(table));
        printf("feature=%2d, thr=%6.2lf, gain=%lf\n",bstAttr, bstThresh, myNode->gain);
        myNode->rightChild = makeTree(rightExamples, findDefaultClass(table));

    }

    return myNode;
}





void calcAccuracy(const vector <int> &vals, const vector<vector <double> > &data){
    int classLabel = data[0].size() - 1;
    double accuracy;
    vector<int> accTable;
    int n;
    cout<<"\n\nOutput : \n";
    for(int i = 0; i < data.size(); i++){
        if(vals[i] == (int)data[i][classLabel]) accuracy = 1;
        else accuracy = 0;
        accTable.push_back(accuracy);
        printf("ID=%5d, predicted=%3d, true=%3d, accuracy=%4.2lf\n",i,vals[i],(int)data[i][classLabel],accuracy);
    }

    double classification_accuracy = 0;
    for(int i = 0; i < accTable.size(); i++) classification_accuracy += accTable[i];

    classification_accuracy = classification_accuracy/accTable.size();
    printf("classification accuracy=%6.4lf\n", classification_accuracy);
}





int main(int argc, const char *argv[]){

    vector<vector <double> > trainingTable;

    string training = argv[1];
    string test = argv[2];
    option = argv[3];
    vector<vector <double> > data;
    readFile(trainingTable, training);
    int defaultClass = findDefaultClass(trainingTable);
    node* tree = new node;
    tree = makeTree(trainingTable, defaultClass);

    readFile(data, test);
    vector<int> vals;

    for (int i = 0; i < data.size() ; i++){
        int predicted = testData(data[i], tree, defaultClass);
        vals.push_back(predicted);
    }
    calcAccuracy(vals, data);

    return 0;
}



