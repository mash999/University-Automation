Assignment 03

Name & Id

RUHUL MASHBU
1330104042


The program is implemented using C++ as the language.

How to run it:
1.open in code blocks or any other editor that supports c++
2.compile the code from the editor. In code blocks, you can press
  shift+cntrl+F9. Or you can find the compile option on the toolbar 
  of codeblocks under "Debug>comfile current file".

3. open command prompt.
4. go to directory of the program 
5. run the command in the following format

   "name of the file" "training_set.txt" "test_set.txt" "option"
   example : 	
   decisionTree.exe yeast_training.txt yeast_test.txt optimized




